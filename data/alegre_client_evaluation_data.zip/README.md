# Datasets for Alegre Fact Recall Evaluation

To evaluate Alegre's ability to recall facts (i.e. a user asks some question or copy/pastes some assertion they found online, and then we look up that text to attempt to find a relevant match), we ran several tests which employed several datasets:

## Similarity Engines
We used several models for looking up facts within ElasticSearch. When we store a fact, we have to, at some point in the future, pull this fact back down when given some search string that is likely highly related to this stored string. There's tons of ways to do information retrieval (IR) - for reasons, these are the three that we attempted to use

### `elasticsearch`
We attempted to use ElasticSearch's (ES) native IR setup which is a mix of boolean operators and similarity distance measures. The benefit is that it's very fast, since it's native to ES, but the original theory was that it would be fairly brittle.

### `wordvec-glove-6B-50d`
`Word2Vec` vector spaces are a canonical vector space approach of sorts, so we wanted to include it as a baseline. When we store the document, we have to process the text into a vector and store that vector - this takes way more time, but may be less brittle.

### `universal-sentence-encoder-large`
`UniversalSentenceEncoder` is included as an improved and more robust model compared to `Word2Vec`. When we store the document, we have to process the text into a vector and store that vector - this takes way more time, but may be less brittle.

## Datasets

### `texts.csv`
This file is about 3,800 headlines with a similarity measure - each row is comprised of `[similarity_score],[text_1],[text_2]`, where the similarity score is from 0 to 5, 5 being most similar. In practice, if the score is over 4 we're considering them to be the effectively the same document.

### `confounder_headlines.csv`
This file is 10,000 random headlines from the news between around 2000 and 2017, one headline per line. The dataset was sourced from [Kaggle]([https://www.kaggle.com/therohk/million-headlines/version/2](https://www.kaggle.com/therohk/million-headlines/version/2)).

### `dev-v2.0.json`
This file is sourced from the [SQuAD dataset]([https://rajpurkar.github.io/SQuAD-explorer/](https://rajpurkar.github.io/SQuAD-explorer/)) from Stanford. The file is a comparably dense nested structure of thematically-grouped paragraphs where each paragraph is accompanied by a series of relevant questions that are either possible or impossible (i.e. answerable given the text), and if possible, an answer is provided with the point in the string of where the answer was located. In practice, we are only using the relevant question strings and the paragraph to which those questions refer.

### `train-v2.0.json`
This file is also sourced from the [SQuAD dataset]([https://rajpurkar.github.io/SQuAD-explorer/](https://rajpurkar.github.io/SQuAD-explorer/)) from Stanford. This file has the same structure as the `dev-v2.0.json` file.

### `ciper_news_dataset.json`
This dataset is sourced from [https://users.dcc.uchile.cl/~voyanede/cc5213/datasets/ciperchile_21.12.2018/](https://users.dcc.uchile.cl/~voyanede/cc5213/datasets/ciperchile_21.12.2018/). 3k headline / content pairs from a Chilean news source used for assessing non-english fact retrieval in Alegre.

## Evaluation Tests
### Basic Evaluation (B)
The B evaluation takes a set of "fact pairs", or lookup/store pairs of texts known to be highly related, and stores one side of that pair in the database. Once all texts are stored, we send in the non-stored fact as a query, expecting the response to be the other side of the pair that we stored. If the first result is our expected result, the test is successful. If it's in the search results, we call it a partial success. If it is not in the results at all, but there are results, we call it a false positive. If there are no results at all, we call that a false negative. This test approximates a simple recall environment, and we use the `texts.csv` file for it.

### Basic with Confounders Evaluation (BC)
The BC evaluation expands the B evaluation, but now includes 10,000 "confounder" texts from `confounder_headlines.csv` that are erroneously stored in the ElasticSearch database. We run the same test as in B but now in an environment filled with potential false positives.

### Confounders with Missing  Cases Evaluation (CWM)
The CWM evaluation expands the BC evaluation, but half of the facts we previously stored from the `texts.csv` file have been left out of storage. We still look up those facts, simulating a situation where people may look up facts we don't yet have answers for. When we fail to return documents for those cases, we call that a true negative.

## Evaluation Space
We ran evaluations for `elasticsearch`, `wordvec-glove-6B-50d`, and `universal-sentence-encoder-large` across the B, BC, and CWM evaluations. Additionally, to consider the effect of imbalanced corpora sizes (e.g. small input from user, large input in our database), we used replaced the data sourced from `texts.csv` with data from `dev-v2.0.json` and the data sourced from `confounder_headlines.csv` with data from `train-v2.0.json` for a "QA" version of B, BC, and CWM. Relevant discussions of those results are in tickets [7902]([https://mantis.meedan.com/view.php?id=7902](https://mantis.meedan.com/view.php?id=7902)) and [8169]([https://mantis.meedan.com/view.php?id=8169](https://mantis.meedan.com/view.php?id=8169)), and a Datasheet for all the results is available in [Google Sheets]([https://docs.google.com/spreadsheets/d/13CLDBisuXJlNBz0htI4QXXVpI3_GyHK_5zDHD5jCvqA/edit](https://docs.google.com/spreadsheets/d/13CLDBisuXJlNBz0htI4QXXVpI3_GyHK_5zDHD5jCvqA/edit))
